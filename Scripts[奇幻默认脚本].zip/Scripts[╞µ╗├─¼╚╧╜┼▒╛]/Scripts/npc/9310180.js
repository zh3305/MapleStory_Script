function start() {
	cm.dispose();
	cm.openNpc(2008, 1);
}
function enter(pi) {
    //idk
}
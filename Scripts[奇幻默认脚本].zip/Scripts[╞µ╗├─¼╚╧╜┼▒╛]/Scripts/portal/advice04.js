function enter(pi) {
    pi.showInstruction("Click \r\\#b<Sera>", 100, 5);
}
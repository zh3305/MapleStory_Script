function enter(pi) {
    pi.warp(980010020);
    return true;
}
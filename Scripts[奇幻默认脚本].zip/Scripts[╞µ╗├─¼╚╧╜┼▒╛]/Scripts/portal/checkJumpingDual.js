function enter(pi) { //not in GMS O_o
    pi.playPortalSE();
    pi.warp(103000003, "out00");
}
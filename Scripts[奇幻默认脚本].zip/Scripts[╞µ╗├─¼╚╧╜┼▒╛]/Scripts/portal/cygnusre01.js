function enter(pi) {
    pi.playPortalSE();
    pi.warp(100000202);
    return true;
}
function enter(pi) {
    pi.playPortalSE();
    pi.warp(100000201, "out02");
    return true;
}
function enter(pi) {
    pi.warp(310000003, 0); //quest
}
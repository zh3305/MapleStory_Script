function enter(pi) {
    pi.warp(910510100, 0);
}
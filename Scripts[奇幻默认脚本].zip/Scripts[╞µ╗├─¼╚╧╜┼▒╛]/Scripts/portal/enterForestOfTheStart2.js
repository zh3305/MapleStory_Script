function enter(pi) {
    pi.playPortalSE();
    pi.warp(130030001, "east00");
    return true;
}
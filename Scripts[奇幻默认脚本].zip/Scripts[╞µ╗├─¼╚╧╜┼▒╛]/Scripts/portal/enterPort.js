function enter(pi) {
    pi.warp(140020300, 1);
}
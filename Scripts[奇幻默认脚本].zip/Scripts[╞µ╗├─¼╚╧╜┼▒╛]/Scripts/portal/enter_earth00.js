function enter(pi) {
    pi.warp(221000300, "earth00");
}
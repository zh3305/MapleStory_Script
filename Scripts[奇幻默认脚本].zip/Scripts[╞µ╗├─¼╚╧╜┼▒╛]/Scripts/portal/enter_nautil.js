function enter(pi) {
    pi.playPortalSE();
    pi.warp(120010000, "nt01");
}
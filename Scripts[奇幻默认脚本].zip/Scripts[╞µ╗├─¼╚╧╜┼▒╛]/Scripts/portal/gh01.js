function enter(pi) {
    pi.playPortalSE();
    pi.saveLocation("TURNEGG")
    pi.warp(749050400, "out00");
}
function enter(pi) {
	pi.openNpc(9390124,1);
        pi.playPortalSE();
}
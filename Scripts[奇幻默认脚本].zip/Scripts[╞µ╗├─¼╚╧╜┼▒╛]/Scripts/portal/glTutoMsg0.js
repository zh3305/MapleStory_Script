function enter(pi) {
    pi.showInstruction("Once you leave this area you won't be able to return.", 150, 5);
}
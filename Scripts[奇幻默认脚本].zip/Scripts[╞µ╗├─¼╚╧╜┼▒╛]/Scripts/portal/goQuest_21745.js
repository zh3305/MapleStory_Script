function enter(pi) {
    pi.warp(925041001, 0);
}
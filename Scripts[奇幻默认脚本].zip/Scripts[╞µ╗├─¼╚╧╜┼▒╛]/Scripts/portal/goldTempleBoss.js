function enter(pi) {
    pi.openNpc(9000080)
}
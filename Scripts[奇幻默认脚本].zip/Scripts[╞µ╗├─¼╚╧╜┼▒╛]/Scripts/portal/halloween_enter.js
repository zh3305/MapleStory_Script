/*
Enter the Haunted House (used to be NX only o.op)
*/

function enter(pi) {
    pi.playPortalSE();
    pi.warp(682000100, "st00");
}
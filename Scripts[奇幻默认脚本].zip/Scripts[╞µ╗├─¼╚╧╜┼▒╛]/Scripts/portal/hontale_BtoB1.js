function enter(pi) {
    pi.playPortalSE();
    pi.warp(240050101, "st00");
    return true;
}
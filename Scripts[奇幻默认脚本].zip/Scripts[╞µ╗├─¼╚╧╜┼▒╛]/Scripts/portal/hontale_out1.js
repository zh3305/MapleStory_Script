function enter(pi) {
    pi.playPortalSE();
    pi.warp(240060000, "st00");
    return true;
}
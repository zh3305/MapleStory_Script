/*
�ֿ�NPC
*/function action(a,b,c){cm.sendStorage();cm.dispose()};
/* RED 1st impact
    Rooney
    Made by Daenerys
*/var status=-1;function action(a,b,c){1==a?status++:0==status&&(cm.sendNext("It seems like you are really busy right now. If you find some free time down the road, then please see me! You'll experience a Christmas town unlike anything else!"),cm.dispose(),status--);0==status?cm.sendYesNo("Are you curious to see the many adventures Happyville has in store for you? Then let's go!"):1==status&&(cm.warp(209E6,16),cm.dispose())};
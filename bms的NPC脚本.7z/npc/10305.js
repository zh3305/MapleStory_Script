/* RED 1st impact
    Vasily
    Made by Daenerys
*/function action(a,b,c){cm.sendNext("\u4f60\u8fd8\u6ca1\u6709\u505a\u597d\u51fa\u822a\u7684\u51c6\u5907\u554a\u3002");cm.dispose()};
/**
-- Odin JavaScript --------------------------------------------------------------------------------
	Shane - Ellinia (101000000)
-- By ---------------------------------------------------------------------------------------------
	Unknown
-- Version Info -----------------------------------------------------------------------------------
	1.1 - Statement fix [Information]
	1.0 - First Version by Unknown
---------------------------------------------------------------------------------------------------
**/var status=0,check=0;function start(){status=-1;action(1,0,0)}function action(a,b,c){0==a?(cm.sendOk("Alright, see you next time."),cm.dispose()):(1==a?status++:status--,0==status?25>cm.getPlayerStat("LVL")?(cm.sendOk("You must be a higher level to enter the Forest of Patience."),cm.dispose(),check=1):cm.sendYesNo("Hi, i'm Shane. I can let you into the Forest of Patience for a small fee. Would you like to enter for #b5000#k mesos?"):1==status&&1!=check&&(5E3>cm.getMeso()?cm.sendOk("Sorry but it doesn't like you have enough mesos!"):(1==cm.getQuestStatus(2050)||50>cm.getPlayerStat("LVL")?cm.warp(91013E4,0):(1==cm.getQuestStatus(2051)||50<=cm.getPlayerStat("LVL"))&&cm.warp(910130100,0),cm.gainMeso(-5E3)),cm.dispose()))};
/* Author: aaroncsn (MapleSea Like)
	NPC Name: 		Mike
	Map(s): 		Warning Street: Perion Dungeon Entrance(106000300)
	Description: 		Unknown
*/function start(){1==cm.getQuestStatus(2358)&&cm.forceCompleteQuest(2358);cm.dispose()};
/**
-- Odin JavaScript --------------------------------------------------------------------------------
	Treasure Chest - Line 3 Construction Site: B1 <Subway Depot> (103000902)
-- By ---------------------------------------------------------------------------------------------
	Unknown
-- Version Info -----------------------------------------------------------------------------------
	1.1 - Statement fix [Information]
	1.0 - First Version by Unknown
---------------------------------------------------------------------------------------------------
**/function start(){status=-1;action(1,0,0)}function action(a,b,c){2<=status&&0==a?(cm.sendOk("Alright, see you next time."),cm.dispose()):(1==a?status++:status--,0==status&&(1!=cm.getQuestStatus(2055)||cm.haveItem(4031039)?(a=1+Math.floor(6*Math.random()),1==a?cm.gainItem(4010003,2):2==a?cm.gainItem(401E4,2):3==a?cm.gainItem(4010002,2):4==a?cm.gainItem(4010005,2):5==a?cm.gainItem(4010004,2):6==a&&cm.gainItem(4010001,2)):cm.gainItem(4031039,1),cm.warp(103E6,0),cm.dispose()))};
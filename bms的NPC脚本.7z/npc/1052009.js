/**
-- Odin JavaScript --------------------------------------------------------------------------------
	Treasure Chest - Line 3 Construction Site: B2 <Subway Depot> (103000905)
-- By ---------------------------------------------------------------------------------------------
	Unknown
-- Version Info -----------------------------------------------------------------------------------
	1.1 - Statement fix [Information]
	1.0 - First Version by Unknown
---------------------------------------------------------------------------------------------------
**/function start(){status=-1;action(1,0,0)}function action(a,b,c){2<=status&&0==a?(cm.sendOk("Alright, see you next time."),cm.dispose()):(1==a?status++:status--,0==status&&(1!=cm.getQuestStatus(2056)||cm.haveItem(4031040)?(a=1+Math.floor(7*Math.random()),1==a?cm.gainItem(4020005,2):2==a?cm.gainItem(4020006,2):3==a?cm.gainItem(4020004,2):4==a?cm.gainItem(4020001,2):5==a?cm.gainItem(4020003,2):6==a?cm.gainItem(402E4,2):7==a&&cm.gainItem(4020002,2)):cm.gainItem(4031040,1),cm.warp(103E6,0),cm.dispose()))};
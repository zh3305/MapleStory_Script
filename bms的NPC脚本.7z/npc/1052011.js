/**
-- Odin JavaScript --------------------------------------------------------------------------------
	Exit - All Line 3 Construction Site
-- By ---------------------------------------------------------------------------------------------
	Xterminator
-- Version Info -----------------------------------------------------------------------------------
	1.0 - First Version by Xterminator
---------------------------------------------------------------------------------------------------
**/var status=0;function start(){status=-1;action(1,0,0)}function action(a,b,c){0<=status&&0==a?cm.dispose():(1==a?status++:status--,0==status?cm.sendYesNo("This device is connected to the outside. Are you going to give up and leave this place? You'll have to start from\r\nscratch the next time you come in..."):1==status&&(cm.warp(103E6,0),cm.dispose()))};
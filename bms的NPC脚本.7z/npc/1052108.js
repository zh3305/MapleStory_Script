/* Cygnus revamp
	Quest Find the Crumpled Piece of Paper Again
	Knocked Trash Can
    Made by Daenerys
*/function start(){1!=cm.getQuestStatus(2214)||cm.haveItem(4031894)?(cm.sendOk("..."),cm.dispose()):(cm.sendOk("You have found a Crumpled Piece of Paper."),cm.gainItem(4031894,1))};
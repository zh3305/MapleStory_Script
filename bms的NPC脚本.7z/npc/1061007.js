/* Crumbling Statue
	1061007
*/var status=0,zones=0,selectedMap=-1;function start(){status=-1;action(1,0,0)}function action(a,b,c){1<=status&&0==a?cm.dispose():(1==a?status++:status--,0==status?cm.sendNext("The crumbling statue makes you sad :("):1==status?cm.sendYesNo("Would you like to escape the sadness?"):2==status&&(cm.warp(105E6),cm.dispose()))};
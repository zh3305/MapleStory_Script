/*
Dondlass - Nautilus' Port
*/function start(){cm.sendStorage();cm.dispose()};
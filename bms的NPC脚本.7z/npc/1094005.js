/* Author: Xterminator
	NPC Name: 		Bush
	Map(s): 		Victoria Road : Nautilus Harbor (120000000)
	Description: 		Quest
*/var status=0,item;function start(){status=-1;action(1,0,0)}function action(a,b,c){1==a?status++:status--;0==status&&(1==cm.getQuestStatus(2186)&&(a=Math.floor(2*Math.random()),item=0!=a||cm.haveItem(4031853)?1==a?4031854:4031855:4031853,cm.gainItem(item,1),4031853==item?cm.sendNext("I found Abel's glasses."):cm.sendOk("I found a pair of glasses, but it doesn't seem to be Abel's. Abel's pair is horn-rimmed...")),cm.dispose())};
/* 
����NPC
*/function start(){cm.sendYesNo("\u4f60\u60f3\u524d\u5f80\u91d1\u94f6\u5c9b\u660e\u73e0\u6e2f\u5417?")}function action(a,b,c){0==a?cm.sendNext("\u624b\u7eed\u4f1a\u6536\u53d61000\u91d1\u5e01,\u6709\u8db3\u591f\u7684\u91d1\u5e01\u5728\u6765\u627e\u6211\u628a\u3002"):(1E3<=cm.getPlayer().getMeso()&&(cm.gainMeso(-1E3),cm.warp(104E6,0)),cm.dispose())};
/* Dawnveil
    Enter Ellinel Fairy Academy Theme Dungeon
	Chase Tosh the Fairy
    Made by Daenerys
*/var status=-1;function action(a,b,c){1==a?status++:0==status&&(cm.sendNextS("Enjoy your adventure.",5),cm.dispose(),status--);0==status?cm.sendAcceptDecline("Chase after #bTosh the Fairy#k.\r\n\r\n#b(Must be in a party (1 - 6 people) / Level: At least 30)"):1==status&&(cm.warp(101073010,0),cm.dispose())};
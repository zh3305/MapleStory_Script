/* Amon
 * Last Mission : Zakum's Altar (280030000)
 */function start(){cm.sendYesNo("\u4f60\u73b0\u5728\u662f\u60f3\u79bb\u5f00\u8fd9\u91cc\u5417?")}function action(a,b,c){1==a&&cm.warp(211042300,0);cm.dispose()};
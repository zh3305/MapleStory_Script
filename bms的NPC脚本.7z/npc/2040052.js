/**
-- Odin JavaScript --------------------------------------------------------------------------------
	Wiz the Librarian - Helios Tower <Library>(222020000)
-- By ---------------------------------------------------------------------------------------------
	Information
-- Version Info -----------------------------------------------------------------------------------
	1.0 - First Version by Information
---------------------------------------------------------------------------------------------------
**/var status=0,questid=[3615,3616,3617,3618,3630,3633,3639],questitem=[4031235,4031236,4031237,4031238,4031270,4031280,4031298],i;function action(b,c,a){1==b?status++:status--;if(0==status){b=0;c="";for(a=0;a<questid.length;a++)2==cm.getQuestStatus(questid[a])&&(b++,c+="\r\n#v"+questitem[a]+"# #b#t"+questitem[a]+"##k");0==b?(cm.sendOk("#b#h ##k has not returned a single storybook yet."),cm.safeDispose()):cm.sendNext("Let's see.. #b#h ##k have returned a total of #b"+b+"#k books. The list of returned books is as follows:"+c)}else 1==status?cm.sendNextPrev("The library is settling down now thanks chiefly to you, #b#h ##k's immense help. If the story gets mixed up once again, then I'll be counting on you to fix it once more."):2==status&&cm.dispose()};
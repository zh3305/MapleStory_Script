/* 
 *   NPC   : Kenta
 *   Map   : Aquariun - Zoo
 */function start(){cm.dispose()}function action(a,b,c){cm.dispose()};
/* NPC��Ȩ: ���Ƶ�
	NPC����: 		������
	MAP(��ͼID): 	        (910000000)
	NPC����: 		�Ի�
   �����ˣ�����ؼ
*/var status=-1;function action(a,c,b){if(1==a)if(status++,0==status)cm.sendSimple("\u6709\u4ec0\u4e48\u4e8b\u5417\uff1f\r\n\r\n#b#L0#\u4f60\u662f\u8c01\uff1f#l\r\n#L1#\u6211\u60f3\u548c\u4f60\u4ea4\u6613\u3002#l");else{if(1==status){switch(b){case 0:cm.sendNext("\u4e0d\u8ba4\u8bc6\u6211\u5417\uff1f\u6211\u662f\u4e16\u754c\u7b2c\u4e00\u5bcc\u7fc1\u91d1\u5229\u5947\u3002");break;case 1:cm.sendNextPrev("\u6211\u901a\u8fc7\u8d38\u6613\u8d5a\u4e86\u5f88\u591a\u94b1\u3002\u5982\u679c\u4f60\u6709\u4ec0\u4e48\u503c\u94b1\u7684\u4e1c\u897f\uff0c\u53ef\u4ee5\u968f\u65f6\u6765\u627e\u6211\u3002")}cm.dispose()}}else cm.dispose()};
/* 	Siron
	Ariant
*/function start(){cm.sendOk("Just Dancing well is not enough for me. I want to do a marvelous brilliant dance!")}function action(){cm.dispose()};
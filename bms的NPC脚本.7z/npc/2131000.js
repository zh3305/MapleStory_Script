/* Author: aaroncsn(MapleSea Like)(Incomplete)
	NPC Name: 		Athena Pierce
	Map(s): 		Altair Camp: Conference Hall(300000010)
	Description: 		Unknown
*/function start(){cm.sendOk("It is been a while since we left Ossyria to avoid the Black Magician. If not for the world tree, I do not know where we would have been. I have been trying to establish myself here, but that is not easy. I wonder how things are like back home.");cm.dispose()};
/* RED 1st impact
    Vasily (Maple Return skill)
    Made by Daenerys
*/var status=-1;function action(a,b,c){1==a?status++:0==status&&(cm.sendNext("We are just a few miles away from our destination. Just chat with the other passengers while we prepare for landing."),cm.dispose(),status--);0==status?cm.sendYesNo("Are you getting off? The ship is going to depart soon. If you leave, you must wait for the next one to come."):1==status&&(cm.warp(2000100,0),cm.dispose())};
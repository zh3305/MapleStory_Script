/*
 * ��еս��
 */function start(){cm.sendSlideMenu(6,cm.getSlideMenuSelection(6))}function action(b,c,a){1==b&&cm.warp(cm.getSlideMenuDataIntegers(6,a)[0],cm.getSlideMenuDataIntegers(6,a)[1]);cm.dispose()};
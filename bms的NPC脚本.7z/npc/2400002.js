/* RED 1st impact
    Chorus
    Made by Daenerys
*/function start(){cm.sendStorage();cm.dispose()};
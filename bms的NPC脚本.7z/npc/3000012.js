/*
 * ��Ԫ���Ϳ�
 */function start(){cm.sendSlideMenu(5,cm.getSlideMenuSelection(5))}function action(b,c,a){1==b&&cm.warp(cm.getSlideMenuDataIntegers(5,a)[0],cm.getSlideMenuDataIntegers(5,a)[1]);cm.dispose()};
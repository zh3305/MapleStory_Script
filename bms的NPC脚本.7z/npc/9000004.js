/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc>
		       Matthias Butz <matze@odinms.de>
		       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation version 3 as published by
    the Free Software Foundation. You may not use, modify or distribute
    this program under any other version of the GNU Affero General Public
    License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/var status=0,party,preamble,mobcount;function start(){status=-1;action(1,0,0)}function action(a,b,c){-1==a?cm.dispose():0==a?cm.dispose():(1==a?status++:status--,a=cm.getPlayer().getEventInstance(),0==status?(party=a.getPlayers(),preamble=a.getProperty("leaderlastpreamble"),mobcount=a.getProperty("leaderlastmobcount"),null==preamble?(cm.sendOk("Hi. Welcome to the last stage. This is where you fight the #bboss#k. Shall we get started?"),status=9):(isLeader()||(null==mobcount?cm.sendOk("Please tell your #bParty-Leader#k to come talk to me"):cm.warp(109020001,0),cm.dispose()),null==mobcount&&cm.sendYesNo("You're finished?!"))):1==status?0==cm.mapMobCount()?cm.sendOk("Good job! You've killed 'em!"):(cm.sendOk("What are you talking about? Kill those creatures!!"),cm.dispose()):2==status?cm.sendOk("You may continue to the next stage!"):3==status?(cm.clear(),a.setProperty("leaderlastmobcount","done"),b=a.getMapInstance(109020001),c=a.getPlayers(),cm.warpMembers(b,c),cm.givePartyExp(2500,a.getPlayers()),cm.dispose()):10==status&&(a.setProperty("leaderlastpreamble","done"),cm.dispose()))}function isLeader(){return null==cm.getParty()?!1:cm.isLeader()};
/* Dawnveil
    Futuroid
	Gaga
    Made by Daenerys
*/var status=-1;function action(a,b,c){1==a?status++:(0==status&&(cm.sendNextS("Bummer. Let me know when you change your mind.",5,9000021),cm.dispose()),status--);0==status?cm.sendYesNoS("I'm ready to blow the world away with my new invention! Are you ready to make a Futuroid?",5,9000021):1==status&&(cm.sendNextS("You don't have enough parts. Come back with more parts!",5,9000021),cm.dispose())};
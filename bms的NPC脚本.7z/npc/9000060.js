/*
	Gingerman - Witch Tower [Easy Mode]
*/function start(){cm.sendSimple("Whoa, I'm all the way up to the top floor! \n\r #L0##bI want to get out of here#k#l")}function action(a,b,c){cm.warp(98004E4,0);cm.dispose()};
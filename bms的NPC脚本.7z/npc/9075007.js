/*
����ϵͳNPC 9075007

*/function start(){status=-1;action(1,0,0)}function action(a,b,c){-1==a?cm.dispose():0==status&&0==a?cm.dispose():(2==status&&0==a&&(cm.sendNext("\u3002\u3002\u3002"),cm.dispose()),1==a?status++:status--,0==status?cm.sendYesNo("\u786e\u5b9a\u9000\u51fa\u8fdb\u5316\u7cfb\u7edf\uff1f"):1==status&&(cm.warp(957E6),cm.dispose()))};
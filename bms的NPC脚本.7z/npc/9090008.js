/* CYGNUS REVAMP
 *	NPC Name: Nana(K)
 *  Daenerys
 */function action(a,b,c){cm.sendOk("I can answer your questions on the wedding hall.");cm.dispose()};
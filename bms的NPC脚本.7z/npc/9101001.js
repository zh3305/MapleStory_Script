/* Author: Xterminator
	NPC Name: 		Peter
	Map(s): 		Maple Road: Entrance - Mushroom Town Training Camp (3)
	Description: 	Takes you out of Entrace of Mushroom Town Training Camp
*/var status=-1;function action(a,b,c){1==a?status++:status--;0==status?cm.sendNext("You have finished all your trainings. Good job. You seem to be ready to start with the journey right away! Good, I will let you move on to the next place."):1==status?cm.sendNextPrev("But remember, once you get out of here, you will enter a village full with monsters. Well them, good bye!"):2==status&&(cm.warp(4E4,0),cm.gainExp(3),cm.dispose())};
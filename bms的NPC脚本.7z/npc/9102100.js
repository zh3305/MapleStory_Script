/**
-- Odin JavaScript --------------------------------------------------------------------------------
	? - Victoria Road: Pet-Walking Road (100000202)
-- By ---------------------------------------------------------------------------------------------
	Xterminator
-- Version Info -----------------------------------------------------------------------------------
	1.0 - First Version by Xterminator
---------------------------------------------------------------------------------------------------
**/var status=0;function start(){status=-1;action(1,0,0)}function action(a,b,c){0==status&&0==a?(cm.sendNext("#b(I didn't touch this hidden item covered in grass)"),cm.dispose()):(1==a?status++:status--,0==status?1==cm.getQuestStatus(4646)?cm.haveItem(4031921)?(cm.sendNext("#b(What's this... eww... a pet's poop was in there!)"),cm.dispose()):cm.sendYesNo("#b(I can see something covered in grass. Should I pull it out?)"):(cm.sendOk("#b(I couldn't find anything.)"),cm.dispose()):1==status&&(cm.sendNext("I found the item that Pet Trainer Bartos hid... this note."),cm.gainItem(4031921,1),cm.dispose()))};
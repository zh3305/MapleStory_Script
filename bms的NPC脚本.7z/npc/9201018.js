/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc>
		       Matthias Butz <matze@odinms.de>
		       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation version 3 as published by
    the Free Software Foundation. You may not use, modify or distribute
    this program under any other version of the GNU Affero General Public
    License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/* Dr. 90212
	Amoria VIP Eye Change.
 */var status=0,beauty=0,price=1E6,mface=[2E4,20001,20003,20004,20005,20006,20007,20008,20018,20019],fface=[21018,21001,21002,21003,21004,21005,21006,21007,21012,21019],facenew=[];function start(){status=-1;action(1,0,0)}function action(a,c,b){if(-1==a)cm.dispose();else if(0==a&&0==status)cm.dispose();else if(1==a?status++:status--,0==status)cm.sendSimple("Well, hello! Welcome to Amoria Plastic Surgery! Would you like to transform your face into something new? With a #b#t5152022##k, you can let us take care of the rest and have the face you've always wanted~!\r\n#L1#I would like to buy a #b#t5152022##k for "+price+" mesos, please!#l\r\n#L2#I already have a Coupon!#l");else if(1==status)if(1==b)cm.getMeso()>=price?(cm.gainMeso(-price),cm.gainItem(5152022,1),cm.sendOk("Enjoy!")):cm.sendOk("You don't have enough mesos to buy a coupon!"),cm.dispose();else{if(2==b){facenew=[];if(0==cm.getPlayer().getGender())for(a=0;a<mface.length;a++)facenew.push(mface[a]+cm.getPlayer().getFace()%1E3-cm.getPlayer().getFace()%100);if(1==cm.getPlayer().getGender())for(a=0;a<fface.length;a++)facenew.push(fface[a]+cm.getPlayer().getFace()%1E3-cm.getPlayer().getFace()%100);cm.sendStyle("Let's see... I can totally transform your face into something new. Don't you want to try it? For #b#t5152022##k, you can get the face of your liking. Take your time in choosing the face of your preference.",facenew)}}else 2==status&&(1==cm.haveItem(5152022)?(cm.gainItem(5152022,-1),cm.setFace(facenew[b]),cm.sendOk("Enjoy your new and improved face!")):(cm.sendOk("Hmm ... it looks like you don't have the coupon specifically for this place. Sorry to say this, but without the coupon, there's no plastic surgery for you..."),cm.dispose()))};
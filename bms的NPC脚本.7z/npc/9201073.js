/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc>
		       Matthias Butz <matze@odinms.de>
		       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation version 3 as published by
    the Free Software Foundation. You may not use, modify or distribute
    this program under any other version of the GNU Affero General Public
    License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/*
@	Author : Raz
@
@	NPC = Sgt.Anderson
@	Map =  Abandoned Tower <Stage 1>
@	NPC MapId = 922010100
@	NPC Exit-MapId = 221024500
@
 */
//4001022 - PASS OF DIMENSION
var status=0;function start(){cm.sendYesNo("Are you sure you want to leave?")}function action(a,b,c){-1==a?cm.dispose():0==a?(cm.sendOk("OK, Talk to me again if you want to leave here."),cm.dispose()):(1==a?status++:status--,109050001==cm.getPlayer().getMap().getId()?0==status?cm.sendNext("See ya."):1==status&&(cm.warp(109060001),cm.dispose()):1==status?cm.sendNext("Ok, Bye!"):2==status?(a=cm.getPlayer().getEventInstance(),null==a?cm.sendOk("Wait, Hey! how'd you get here?\r\nOh well you can leave anyways"):(isLeader()?(a.disbandParty(),cm.removeFromParty(4001008,a.getPlayers())):(a.leftParty(cm.getPlayer()),cm.removeAll(4001008),cm.removeAll(4031059),cm.removeAll(4001102),cm.removeAll(4001108)),cm.dispose())):3==status&&(cm.warp(109050001),cm.removeAll(4001008),cm.removeAll(4031059),cm.removeAll(4001102),cm.removeAll(4001108),cm.dispose()))}function isLeader(){return null==cm.getParty()?!1:cm.isLeader()};
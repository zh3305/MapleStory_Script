/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc>
		       Matthias Butz <matze@odinms.de>
		       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation version 3 as published by
    the Free Software Foundation. You may not use, modify or distribute
    this program under any other version of the GNU Affero General Public
    License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/status=-1;var sel,pickup=-1;function start(){cm.sendSimple("I'm Abdula, and I am a merchant intermediary who deals with rare goods. What do you have for me?#b\r\n#L0#I want to sell goods.\r\n#L1#I want to know about current market prices.\r\n#L2#A merchant intermediary? What is that?")}function action(a,b,c){status++;if(1!=a){if(0==a&&0==status){cm.dispose();return}if(0==a&&0==sel&&2==status){cm.sendNext("You don't want to sell it right now? You can sell it later, but remember the Special Items are only valuable for a week.");cm.dispose();return}0==a&&2==sel&&(status-=2)}if(0==status)if(void 0==sel&&(sel=c),0==c){a="Let's see what you brought...#b";for(b=0;5>b;b++)a+="\r\n#L"+b+"##t"+(3994090+b)+"#";cm.sendSimple(a)}else if(1==c){a="";for(b=0;5>b;b++)a+="The current market price for #t"+(b+3994090)+"# is #rNOT DONE#k mesos\r\n";cm.sendNext(a);cm.dispose()}else cm.sendNext("I buy the products at the Maple 7th Day Market and sell them in other towns. I trade memorabilia, spices, taxidermy shark, and more... but no Lazy Daisy's eggs.");else 1==status?0==sel?cm.haveItem(3994090+c)?(pickup=3994090+c,cm.sendYesNo("The current price is 180 mesos. Would you like to sell it now?")):(cm.sendNext("You don't have anything. Stop wasting my time... I'm a busy person."),cm.dispose()):cm.sendNextPrev("Maple 7th Day Market Sundays are my days off. If you need to see me, you're going to have to come Monday to Friday..."):2==status?0==sel?cm.sendGetNumber("How many would you like to sell?",0,0,200):cm.sendPrev("Oh, and the prices are subject to change. I can't get the short end of the stick, I have to stay in business! Check back with me frequently, my prices change by the hour!"):3==status&&(0==sel&&(1!=c?cm.sendNext("Something's not right. Check again."):(cm.sendNext("The transaction has been completed. See you next time."),cm.gainMeso(180),cm.gainItem(pickup,-1))),cm.dispose())};
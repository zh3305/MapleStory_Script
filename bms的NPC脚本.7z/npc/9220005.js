/* Roudolph Happyville Warp NPC
   By Moogra
*/function start(){cm.sendYesNo("Do you want to go to the Extra Frosty Snow Zone ?")}function action(a,b,c){0<a&&cm.warp(20908E4,0);cm.dispose()};
/* 	Airu
	Singapore
*/function start(){cm.sendOk("Students, you better study! How can I help you honey?")}function action(){cm.dispose()};
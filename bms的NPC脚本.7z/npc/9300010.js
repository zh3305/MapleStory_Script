/* 
	�ű�����: 		NPC
	���ڵ�ͼ:		���ǵ�
	�ű�����:		����ͼ�뿪NPC
*/var status=0;function start(){status=-1;action(1,0,0)}function action(a,b,c){-1==a?cm.dispose():(1==a?status++:status--,-1==status?cm.dispose():0==status?cm.sendSimple("\u79bb\u5a5a\u53ef\u80fd\u662f\u4e00\u4ef6\u5f88\u9c81\u83bd\u7684\u51b3\u5b9a\uff0c\u4f60\u53ef\u80fd\u51b3\u5b9a\u4e86\uff0c\u6211\u4e5f\u4e0d\u591a\u8bf4\u4ec0\u4e48\u4e86\u3002#b\r\n#L0# \u6211\u60f3\u79bb\u5f00\u8fd9\u91cc\u3002"):1==status&&(cm.warp(7E8),cm.dispose()))};
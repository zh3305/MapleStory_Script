/* Author: aaroncsn (MapleSea Like)
	NPC Name: 		Yang the Pilot
	Map(s): 		China Shanghai- Temporary Airport(701000100)
	Description: 		Pilot
*/function start(){cm.sendOk("Don't you wish to fly high so you can touch the sky?");cm.dispose()};
/* Dawnveil
    enterPortal
	??????
    Made by Daenerys
*/var status=-1;function action(a,b,c){1==a?status++:status--;0==status?cm.sendNextS("Insignificant child! Are you deaf to the fury of the old world? Can you not hear the roars of pain and resentment that echo around you? Discard whatever foot touched the corruption of this soil, and escape while you can. THe Heart Tree's corruption touches the very ground you stand upon.",4):1==status?cm.sendYesNoS("What the heck was that?! I feel like someone was yelling inside my bones. Should I keep going?",16):2==status&&(cm.warp(863000100,0),cm.dispose())};
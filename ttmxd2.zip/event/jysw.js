var mapId = 746000015;

function init() {
    em.setProperty("state", "0");
    em.setProperty("leader", "true");
}

function setup(eim, leaderid) {
    em.setProperty("state", "1");
    em.setProperty("leader", "true");
    var eim = em.newInstance("Vergamot" + leaderid);

    eim.setProperty("vergamotSummoned", "0");

    var map = eim.setInstanceMap(mapId);
    map.resetFully();
    //var overrideStats = em.newMonsterStats();
    var mob = em.getMonster(2500320);//��ħèͷӥ��
    var hprand = 500000000;
	var overrideStats = em.newMonsterStats();
    overrideStats.setOHp(hprand);
    overrideStats.setOExp(50000);
    overrideStats.setOMp(500000);
    mob.setOverrideStats(overrideStats);
    //mob.setOverrideStats(overrideStats);
    //mob.setHp(hprand);
    eim.registerMonster(mob);
    map.spawnMonsterOnGroundBelow(mob, new java.awt.Point(505,95)); //ˢ���������
    eim.schedule("timeout", 300 * 1000);//10���� 
    eim.schedule("beginQuest", 1000);
    return eim;
}

function playerEntry(eim, player) {
    var map = eim.getMapInstance(0);
    player.changeMap(map, map.getPortal(0));
}

function playerRevive(eim, player) {
    return false;
}

function scheduledTimeout(eim) {
    end(eim);
}

function timeout(eim) {
    end(eim);
}

function changedMap(eim, player, mapid) {
    if (mapid != 746000015) {
        eim.unregisterPlayer(player);

        if (eim.disposeIfPlayerBelow(0, 0)) {
            em.setProperty("state", "0");
            em.setProperty("leader", "true");
        }
    }
}

function playerDisconnected(eim, player) {
    return 0;
}

function monsterValue(eim, mobId) {
    return 1;
}

function playerExit(eim, player) {
    eim.unregisterPlayer(player);

    if (eim.disposeIfPlayerBelow(0, 0)) {
        em.setProperty("state", "0");
        em.setProperty("leader", "true");
    }
}

function clearPQ(eim) {
    end(eim);
}

function end(eim) {
    var map = eim.getMapInstance(746000015);
    eim.broadcastPlayerMsg(1, "����ʱ�䵽��,���˳��˸���");
    eim.disposeIfPlayerBelow(100, 910000000);
    em.setProperty("state", "0");
    em.setProperty("leader", "true");
}

function monsterSpawn(eim) {
	 var map = eim.getMapInstance(746000015);
         if (map.getAllMonstersThreadsafe().size() <= 80) {
         var overrideStats = em.newMonsterStats();
         for (var i = 0; i < 2; i++) {
         var mob = em.getMonster(2400129);//����
         var hprand = 3000000;
         overrideStats.setOHp(hprand);
         overrideStats.setOExp(50000);
         overrideStats.setOMp(20000);
         mob.setOverrideStats(overrideStats);
         mob.setHp(hprand);
         eim.registerMonster(mob);
         map.spawnMonsterOnGroundBelow(mob, new java.awt.Point(278,95)); //ˢ���������
         }
         for (var i = 0; i < 2; i++) {
         var mob = em.getMonster(2400129);//����
         var hprand = 7000000;
         overrideStats.setOHp(hprand);
         overrideStats.setOExp(50000);
         overrideStats.setOMp(200000);
         mob.setOverrideStats(overrideStats);
         mob.setHp(hprand);
         eim.registerMonster(mob);
         map.spawnMonsterOnGroundBelow(mob, new java.awt.Point(278,95)); //ˢ���������
         }
         for (var i = 0; i < 2; i++) {
         var mob = em.getMonster(2400129);//����
         var hprand = 3000000;
         overrideStats.setOHp(hprand);
         overrideStats.setOExp(50000);
         overrideStats.setOMp(200000);
         mob.setOverrideStats(overrideStats);
         mob.setHp(hprand);
         eim.registerMonster(mob);
         map.spawnMonsterOnGroundBelow(mob, new java.awt.Point(48,95)); //ˢ���������
         }
         for (var i = 0; i < 4; i++) {
         var mob = em.getMonster(2400129);//����
         var hprand = 3000000;
         overrideStats.setOHp(hprand);
         overrideStats.setOExp(50000);
         overrideStats.setOMp(200000);
         mob.setOverrideStats(overrideStats);
         mob.setHp(hprand);
         eim.registerMonster(mob);
         map.spawnMonsterOnGroundBelow(mob, new java.awt.Point(48,95)); //ˢ���������
         }
	 eim.schedule("monsterSpawn", 10000);
         map.startMapEffect("����������10��󵽴�,��ץ������,,��ǰ��Ϯ��������" + map.getAllMonstersThreadsafe().size() + "", 5121037);
	 map.broadcastMessage(em.getClock(10));
         } else if (map.getAllMonstersThreadsafe().size() > 80 && map.getAllMonstersThreadsafe().size() < 100 ) {
         var overrideStats = em.newMonsterStats();
         for (var i = 0; i < 2; i++) {
         var mob = em.getMonster(2400129);//����
         var hprand = 4000000;
         overrideStats.setOHp(hprand);
         overrideStats.setOExp(50000);
         overrideStats.setOMp(200000);
         mob.setOverrideStats(overrideStats);
         mob.setHp(hprand);
         eim.registerMonster(mob);
         map.spawnMonsterOnGroundBelow(mob, new java.awt.Point(202,95)); //ˢ���������
         }
         for (var i = 0; i < 2; i++) {
         var mob = em.getMonster(2400129);//����
         var hprand = 3000000;
         overrideStats.setOHp(hprand);
         overrideStats.setOExp(50000);
         overrideStats.setOMp(200000);
         mob.setOverrideStats(overrideStats);
         mob.setHp(hprand);
         eim.registerMonster(mob);
         map.spawnMonsterOnGroundBelow(mob, new java.awt.Point(202,95)); //ˢ���������
         }
         for (var i = 0; i < 2; i++) {
         var mob = em.getMonster(2400129);//����
         var hprand = 8000000;
         overrideStats.setOHp(hprand);
         overrideStats.setOExp(50000);
         overrideStats.setOMp(200000);
         mob.setOverrideStats(overrideStats);
         mob.setHp(hprand);
         eim.registerMonster(mob);
         map.spawnMonsterOnGroundBelow(mob, new java.awt.Point(-64,95)); //ˢ���������
         }
         for (var i = 0; i < 4; i++) {
         var mob = em.getMonster(2400129);//����
         var hprand = 3000000;
         overrideStats.setOHp(hprand);
         overrideStats.setOExp(50000);
         overrideStats.setOMp(200000);
         mob.setOverrideStats(overrideStats);
         mob.setHp(hprand);
         eim.registerMonster(mob);
         map.spawnMonsterOnGroundBelow(mob, new java.awt.Point(-64,95)); //ˢ���������
         }       
	 eim.schedule("monsterSpawn", 10000);
	 map.broadcastMessage(em.getClock(10));
         map.startMapEffect("��ǰ��ͼ���ڸ漱״̬,���ǿ������ֹ������Ϯ,��ǰ��������" + map.getAllMonstersThreadsafe().size() + "������100ֻ���ｫ���˳�����", 5121037);   
	 }else{      
         eim.broadcastPlayerMsg(1, "���ѱ������ܣ�����ʧ��");
         eim.disposeIfPlayerBelow(100, 910000000);//�˳�����
         em.setProperty("state", "0");
         em.setProperty("leader", "true");
         }
         }
function beginQuest(eim) {
	var map = eim.getMapInstance(746000015);
        map.startMapEffect("����ʱ��Ϊ5����,����������10��󵽴��ץ������ע���Ϸ���ʯ", 5121037);
	eim.schedule("monsterSpawn", 10000);
	map.broadcastMessage(em.getClock(10));
}
function leftParty(eim, player) {}
function allMonstersDead(eim) {
//has nothing to do with monster killing
}
function disbandParty(eim) {}

function playerDead(eim, player) {}

function cancelSchedule() {}
function start(ms) {
    ms.handlePinkBeanStart();
}

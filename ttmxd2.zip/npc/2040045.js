/*
	Pink Balloon - LudiPQ Bonus stage NPC
*/

function start() {
	cm.warp(922011100);
	cm.dispose();
}

function action(mode, type, selection) {
    cm.dispose();
}
function start(){
cm.dispose();
}
function start() {
	cm.dispose();
	cm.openNpc(9330189, 1);
}
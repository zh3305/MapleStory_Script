function start() {
	cm.dispose();
	cm.openNpc(9390013);
}
function enter(pi) {
    pi.warp(271000000, 0);
}
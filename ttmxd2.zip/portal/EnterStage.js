function enter(pi) {
    pi.openNpc(9330189);
    return true;
}
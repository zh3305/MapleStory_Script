function enter(pi) {
    pi.warpS(pi.getMapId(), "st00");
}
function enter(pi) {
    pi.openNpc(9900003, 300);
}
function enter(pi) {
    pi.teachSkill(20000016, 0, -1);
    pi.teachSkill(20000016, 1, 0);
    pi.playPortalSE();
    pi.warp(914000220, 1);
}
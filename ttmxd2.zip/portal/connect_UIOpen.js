function enter(pi) {
    pi.openNpc(2183001);
    return true;
}
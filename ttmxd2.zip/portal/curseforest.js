function enter(pi) {
    pi.warp(910100000, 0); //or 910100001
}
function enter(pi) {
    //if (pi.getMap().getAllMonstersThreadsafe().size() == 0) {
    //    pi.playerMessage("����ʣ�µĹ��");
    //} else {
    //    pi.dojoAgent_NextMap(true, false);
    //}
	pi.openNpc(2091005,1);
	java.lang.System.out.println("�л���ͼ");
}
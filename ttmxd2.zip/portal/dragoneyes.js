function enter(pi) {
    pi.forceStartQuest(22012);
    return true;
}
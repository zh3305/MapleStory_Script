function enter(pi) {
    pi.playPortalSE();
    pi.warp(101000003, 8);
}
function enter(pi) {
    pi.playPortalSE();
    pi.warp(300000011, 0);
}
function enter(pi) {
    pi.openNpc(2170006);
}
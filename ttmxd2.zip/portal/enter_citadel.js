function enter(pi) {
    pi.warp(401050001, 0);
}
function enter(pi) {
    pi.playPortalSE();
    pi.warp(100030102, "sp");
    return true;
}
function enter(pi) {
	pi.openNpc(2159355);
        pi.playPortalSE();
}
function enter(pi) {
    pi.openNpc(9031000, 1);
}
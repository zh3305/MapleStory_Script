function enter(pi) {
    pi.playPortalSE();
    pi.warp(240020101, "out00");
}
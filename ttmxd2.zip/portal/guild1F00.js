function enter(pi) {
    pi.warp(990000600, 1);
}
function enter(pi) {
    pi.warp(990000700, "st00");
}
function enter(pi) {
	pi.getPlayer().saveLocation(net.sf.odinms.server.maps.SavedLocationType.Pachinko_port);
	pi.warp(809030000, "out00");
	return true;
}
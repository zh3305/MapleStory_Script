function start(ms) {
        ms.getPlayer().getMap().spawnPB();
}
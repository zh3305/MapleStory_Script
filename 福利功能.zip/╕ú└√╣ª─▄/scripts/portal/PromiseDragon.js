function start(ms) {
	ms.showWZEffect("Effect/Direction4.img/PromiseDragon/Scene0", -1);
}
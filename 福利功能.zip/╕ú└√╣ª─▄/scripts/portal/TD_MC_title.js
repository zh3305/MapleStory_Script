function start(ms) {
	ms.showMapEffect("temaD/enter/mushCatle");
}
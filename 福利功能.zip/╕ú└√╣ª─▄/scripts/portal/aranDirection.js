function start(ms) {
	ms.displayAranIntro();
}
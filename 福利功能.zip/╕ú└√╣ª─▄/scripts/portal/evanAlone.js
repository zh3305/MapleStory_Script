function start(ms) {
        ms.lockUI();
	ms.showWZEffect("Effect/Direction4.img/crash/Scene0", -1);
}
function start(ms) {
    var mapid = ms.getPlayer().getMap().getId();
    switch (mapid) {
        case 900010200:
            ms.displayAranIntro();
        case 900010200:
            ms.unlockUI();
        case 100030100:
            ms.unlockUI();
            break;
    }
}
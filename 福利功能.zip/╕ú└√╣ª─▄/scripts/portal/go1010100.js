function start(ms) {
	ms.showMapEffect("maplemap/enter/1010100");
}
function start(ms) {
	ms.unlockUI();
	ms.showMapEffect("maplemap/enter/1020000");
}
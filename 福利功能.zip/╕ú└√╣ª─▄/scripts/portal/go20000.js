function start(ms) {
	ms.unlockUI();
	ms.showMapEffect("maplemap/enter/20000");
}
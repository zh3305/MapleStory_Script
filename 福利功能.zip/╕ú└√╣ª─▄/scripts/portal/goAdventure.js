function start(ms) {
	ms.Adventure();
}
function start(ms) {
	ms.showWZEffect("Effect/Direction3.img/archer/Scene0", -1);
}
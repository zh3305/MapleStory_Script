function start(ms) {
	ms.unlockUI();
	ms.showWZEffect("Effect/Direction3.img/goLith/Scene0", -1);
}
function start(ms) {
	ms.showWZEffect("Effect/Direction3.img/magician/Scene0", -1);
}
function start(ms) {
	ms.showWZEffect("Effect/Direction3.img/pirate/Scene0", -1);
}
function start(ms) {
	ms.showWZEffect("Effect/Direction3.img/rogue/Scene0", -1);
}
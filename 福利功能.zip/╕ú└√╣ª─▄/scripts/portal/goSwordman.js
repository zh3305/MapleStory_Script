function start(ms) {
	ms.showWZEffect("Effect/Direction3.img/swordman/Scene0", -1);
}
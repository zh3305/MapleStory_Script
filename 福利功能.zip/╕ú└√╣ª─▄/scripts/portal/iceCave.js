function start(ms) {
	ms.arriveIceCave();
}
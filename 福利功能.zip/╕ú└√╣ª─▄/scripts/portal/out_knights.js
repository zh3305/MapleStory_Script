function enter(pi) {
	if (pi.getPlayer().getMapId()==271030100) {
		pi.warp(271030010);
		return true;
	}
}
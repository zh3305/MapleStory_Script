function start(ms) {
	ms.enterRien();
}
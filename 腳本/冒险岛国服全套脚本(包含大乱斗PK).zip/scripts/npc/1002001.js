/* 	Cody
*/

function start() {
    cm.sendOk("Hello. I'm Cody. Nice to meet you! =)");
}

function action(mode, type, selection) {
    cm.dispose();
}	
function action(mode, type, selection) {
    cm.sendOk("��ͨ�Ĳݴԡ�");
    cm.safeDispose();
}
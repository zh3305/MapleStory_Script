/*
	Mr. Wang - Victoria Road : Perion (102000000)
*/

function action(mode, type, selection) {
    cm.sendStorage();
    cm.dispose();
}
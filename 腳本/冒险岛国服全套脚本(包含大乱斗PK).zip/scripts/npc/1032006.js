/**
	Mr. Wang - Victoria Road : Ellinia (101000000)
**/

function start() {
    cm.sendStorage();
    cm.dispose();
}
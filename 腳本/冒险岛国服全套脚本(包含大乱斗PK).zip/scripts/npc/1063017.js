function action(mode, type, selection) {
	cm.warp(910510202, 0);
	cm.dispose();
}
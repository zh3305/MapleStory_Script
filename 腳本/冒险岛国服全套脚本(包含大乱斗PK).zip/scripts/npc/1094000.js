/*
Bart - Nautilus' Port
*/


function start() {
    cm.sendOk("I need to keep my eyes wide open to look for the enemy although my sea gull friends help me out so it's not all that bad.");
}

function action(mode, type, selection) {
    cm.dispose();
}

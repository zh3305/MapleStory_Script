function start() {
    cm.warp(130000000);
    cm.dispose();
}
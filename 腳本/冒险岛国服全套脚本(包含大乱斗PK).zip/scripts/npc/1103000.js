function action(mode, type, selection) {
	cm.sendNext("Thank you so much...");
	cm.safeDispose();
}
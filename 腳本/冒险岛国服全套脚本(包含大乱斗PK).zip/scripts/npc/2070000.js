/* 
	Storage
*/

function start() {
    cm.sendStorage();
}

function action(mode, type, selection) {
    cm.dispose();
}
/*
	Mue - Leafre Ticketing Booth(240000100)
*/

var cost = 30000;
var status = -1;

function action(mode, type, selection) {
    cm.sendOk("Hope you enjoy your stay at Leafre.");
    cm.dispose();
}
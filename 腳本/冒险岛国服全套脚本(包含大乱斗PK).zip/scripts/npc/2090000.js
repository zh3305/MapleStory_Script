function start() {
    cm.sendStorage();
    cm.dispose();
}
function start() {
    cm.showDoJangRank();
    cm.dispose();
}
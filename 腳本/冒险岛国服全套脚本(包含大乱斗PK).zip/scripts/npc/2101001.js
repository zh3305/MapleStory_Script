/* 
	Jiyur
	Little Kid
*/

function start() {
    cm.sendNext("I miss my sister... she's always working at the palace as their servant and I only get to see her on Sundays. The King and Queen are so selfish.");
    cm.dispose();
}
/* 
	Byron
	Excavator/Treasure Hunter
*/

function start() {
    cm.sendNext("I thought #rAriant#k was amazing, but Valvendale is just SUPERB! There are so many different landscapes and forms of life. Like #b#ethose weird slimes outside of town#n#k... those are just WEIRD!");
    cm.dispose();
}
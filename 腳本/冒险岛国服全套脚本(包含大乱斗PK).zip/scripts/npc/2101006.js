/* 
	Le Petit Prince
	Son of King and Queen.
*/

function start() {
    cm.sendNext("Home is so boring... my parents ignore me so much it's unbearable. And ever since we moved from #rAriant#k, they've been trying to get a new palace built so they don't have to live outdoors. But I love the outdoors...");
    cm.dispose();
}
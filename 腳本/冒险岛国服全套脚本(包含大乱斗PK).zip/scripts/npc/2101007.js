/* 
	Areda
	Queen
*/

function start() {
    cm.sendNext("NO! Abdullah, I said 17 bedrooms, and 23 bathrooms! CALL THE CONSTRUCTION COMPANY AND CHANGE IT!");
    cm.dispose();
}
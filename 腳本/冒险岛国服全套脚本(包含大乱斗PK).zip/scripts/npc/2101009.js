/* 
	Abdullah VIII
	King
*/

function start() {
    cm.sendNext("Yawnnnn~!");
    cm.dispose();
}
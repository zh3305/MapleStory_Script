/* 	Sejan
	Ariant
*/

function start() {
    cm.sendNext("The light and dark always coexist...");
    cm.dispose()
}
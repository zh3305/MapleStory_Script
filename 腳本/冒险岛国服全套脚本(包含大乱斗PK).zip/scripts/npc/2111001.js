/*
	Magatia - Maed
*/

function start() {
    cm.sendOk("Zenumist......I know what they say. They don't like the combination of life with machine. But it is only about being fearful about machines. Seeking Pure Alchemy won't achieve anything.");
}

function action() {
    cm.dispose();
}
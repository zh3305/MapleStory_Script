function start() {
    cm.getMap().killMonster(7090000);
    cm.dispose();
}

function action(mode, type, selection) {
}
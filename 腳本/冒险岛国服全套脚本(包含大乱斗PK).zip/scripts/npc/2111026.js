function start() {
    cm.getMap().killMonster(8090000);
    cm.dispose();
}

function action(mode, type, selection) {
}

function action(mode, type, selection) {
    cm.dispose();
    cm.openNpc(2152005);
}